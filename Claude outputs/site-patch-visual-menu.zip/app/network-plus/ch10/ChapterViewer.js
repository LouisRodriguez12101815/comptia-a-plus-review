"use client";

import { useCallback, useEffect, useRef, useState } from "react";

/*
 * Chapter visual picker, shared by Chapters 9, 10, and 11.
 *
 * Design decisions:
 * - The list is a numbered table of contents in a clear order, not a pile of
 *   same-looking buttons, so the learner always knows where they are.
 * - The current item has a text label ("Viewing"), a bar, and aria-current,
 *   never color alone.
 * - Previous and Next let a learner go through the set in order without
 *   hunting through the list. "Up next" names the next visual.
 * - Visuals the learner has opened get a check mark and a running count, saved
 *   in this browser only.
 * - On a phone the list folds behind a "Browse all" button so the visual, not a
 *   wall of buttons, is the first thing on screen.
 * - The link hash (#visual-ch9-arp-chase) lets a learner bookmark or share one.
 * - The "(Review questions ...)" note in each description is pulled out into a
 *   separate "Covers" line so the description reads cleanly.
 * Colors come from the CSS variables set by each chapter page.
 */

const COVERS = /^([\s\S]*?)\s*\(([^()]+)\)\.?\s*$/;

function splitDescription(description) {
  const text = (description || "").trim();
  const match = COVERS.exec(text);
  if (match && match[1]) return { text: match[1].trim(), covers: match[2].trim() };
  return { text, covers: "" };
}

function idOf(file) {
  return file.replace(/\.html$/, "");
}

function Check() {
  return (
    <svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true" focusable="false">
      <path d="M3 8.5l3.2 3.2L13 4.8" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export default function ChapterViewer({ visuals }) {
  // Display order: groups in first-appearance order, items in file order inside each group.
  const groups = [...new Set(visuals.map((v) => v.group))];
  const ordered = groups.flatMap((group) => visuals.filter((v) => v.group === group));
  const total = ordered.length;
  const storeKey = `visuals-viewed:${(ordered[0]?.file || "chapter").split("-")[0]}`;

  const [index, setIndex] = useState(0);
  const [open, setOpen] = useState(false);
  const [seen, setSeen] = useState([]);
  const [ready, setReady] = useState(false);
  const headRef = useRef(null);
  const listRef = useRef(null);
  const listId = "cv-list";

  // On first load: restore viewed marks and honor a #visual-... link.
  useEffect(() => {
    let saved = [];
    try {
      saved = JSON.parse(window.localStorage.getItem(storeKey) || "[]");
      if (!Array.isArray(saved)) saved = [];
    } catch {
      saved = [];
    }
    setSeen(saved);
    const fromHash = () => {
      const hash = window.location.hash.replace(/^#visual-/, "");
      const found = hash ? ordered.findIndex((v) => idOf(v.file) === hash) : -1;
      if (found > -1) setIndex(found);
    };
    fromHash();
    setReady(true);
    window.addEventListener("hashchange", fromHash);
    return () => window.removeEventListener("hashchange", fromHash);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const current = ordered[index];

  // Mark the visual on screen as viewed and keep the link in sync.
  useEffect(() => {
    if (!ready) return;
    setSeen((prev) => {
      if (prev.includes(current.file)) return prev;
      const next = [...prev, current.file];
      try {
        window.localStorage.setItem(storeKey, JSON.stringify(next));
      } catch {
        /* storage can be blocked; the page still works */
      }
      return next;
    });
    try {
      window.history.replaceState(null, "", `#visual-${idOf(current.file)}`);
    } catch {
      /* ignore */
    }
  }, [current.file, ready, storeKey]);

  useEffect(() => {
    const list = listRef.current;
    if (!list || list.offsetParent === null) return;
    const btn = list.querySelector('[aria-current="true"]');
    if (!btn) return;
    const lr = list.getBoundingClientRect();
    const br = btn.getBoundingClientRect();
    const top = br.top - lr.top + list.scrollTop;
    const bottom = top + br.height;
    if (top < list.scrollTop + 8) list.scrollTop = Math.max(0, top - 8);
    else if (bottom > list.scrollTop + list.clientHeight - 8) list.scrollTop = bottom - list.clientHeight + 8;
  }, [index, ready]);

  const go = useCallback(
    (next, { fromList = false } = {}) => {
      if (next < 0 || next >= total) return;
      setIndex(next);
      setOpen(false);
      if (fromList || window.matchMedia("(max-width: 899px)").matches) {
        window.requestAnimationFrame(() => {
          const el = headRef.current;
          if (!el) return;
          if (window.matchMedia("(max-width: 899px)").matches) el.scrollIntoView({ block: "start" });
          el.focus({ preventScroll: true });
        });
      }
    },
    [total]
  );

  function resetSeen() {
    try {
      window.localStorage.removeItem(storeKey);
    } catch {
      /* ignore */
    }
    setSeen([current.file]);
  }

  const { text, covers } = splitDescription(current.description);
  const seenCount = ordered.filter((v) => seen.includes(v.file)).length;
  const prev = index > 0 ? ordered[index - 1] : null;
  const next = index < total - 1 ? ordered[index + 1] : null;

  let counter = 0;

  return (
    <div className={`cv${open ? " cv-open" : ""}`}>
      <style>{css}</style>

      <p className="cv-sr" role="status" aria-live="polite">
        {`Showing visual ${index + 1} of ${total}: ${current.title}`}
      </p>

      <div className="cv-bar">
        <button
          type="button"
          className="cv-browse"
          aria-expanded={open}
          aria-controls={listId}
          onClick={() => setOpen((o) => !o)}
        >
          <span aria-hidden="true">{open ? "✕" : "☰"}</span>
          {open ? "Close the list" : `Browse all ${total} visuals`}
        </button>
        <p className="cv-pos">
          <strong>
            Visual {index + 1} of {total}
          </strong>
          <span>
            {" "}
            · {seenCount} viewed
          </span>
        </p>
        <div className="cv-steps">
          <button type="button" className="cv-btn" onClick={() => go(index - 1)} disabled={!prev}>
            <span aria-hidden="true">{"←"}</span> Previous
          </button>
          <button type="button" className="cv-btn cv-primary" onClick={() => go(index + 1)} disabled={!next}>
            Next <span aria-hidden="true">{"→"}</span>
          </button>
        </div>
      </div>

      <div className="cv-body">
        <nav
          id={listId}
          ref={listRef}
          aria-label="Chapter visuals"
          className="cv-list"
          onKeyDown={(e) => {
            if (e.key === "Escape") setOpen(false);
          }}
        >
          {groups.map((group, gi) => {
            const items = ordered.filter((v) => v.group === group);
            const labelId = `cv-g-${gi}`;
            return (
              <section key={group} className="cv-group">
                <p id={labelId} className="cv-group-label">
                  <span>{group}</span>
                  <span className="cv-count">
                    {items.length} {items.length === 1 ? "visual" : "visuals"}
                  </span>
                </p>
                <ol aria-labelledby={labelId} className="cv-items">
                  {items.map((v) => {
                    counter += 1;
                    const n = counter;
                    const active = v.file === current.file;
                    const viewed = seen.includes(v.file);
                    return (
                      <li key={v.file}>
                        <button
                          type="button"
                          className="cv-item"
                          aria-current={active ? "true" : undefined}
                          onClick={() => go(n - 1, { fromList: true })}
                        >
                          <span className="cv-num" aria-hidden="true">
                            {n}
                          </span>
                          <span className="cv-title">{v.title}</span>
                          {active ? (
                            <span className="cv-tag">Viewing</span>
                          ) : viewed ? (
                            <span className="cv-done">
                              <Check />
                              <span className="cv-sr">Viewed</span>
                            </span>
                          ) : null}
                        </button>
                      </li>
                    );
                  })}
                </ol>
              </section>
            );
          })}
          <div className="cv-foot">
            <span>
              {seenCount} of {total} viewed
            </span>
            {seenCount > 1 ? (
              <button type="button" className="cv-link" onClick={resetSeen}>
                Clear viewed marks
              </button>
            ) : null}
          </div>
        </nav>

        <div className="cv-main">
          <header className="cv-head">
            <p className="cv-kicker">{current.group}</p>
            <h3 ref={headRef} tabIndex={-1}>
              {current.title}
            </h3>
            <p className="cv-text">{text}</p>
            {covers ? (
              <p className="cv-covers">
                <strong>Covers:</strong> {covers}
              </p>
            ) : null}
            <a
              className="cv-btn cv-open-link"
              href={`/visuals/${current.file}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              Open full screen <span aria-hidden="true">{"↗"}</span>
              <span className="cv-sr"> (opens in a new tab)</span>
            </a>
          </header>

          <iframe key={current.file} className="cv-frame" src={`/visuals/${current.file}`} title={current.title} />

          <div className="cv-next">
            {next ? (
              <button type="button" className="cv-upnext" onClick={() => go(index + 1)}>
                <span className="cv-upnext-label">Up next</span>
                <span className="cv-upnext-title">
                  {next.title} <span aria-hidden="true">{"→"}</span>
                </span>
              </button>
            ) : (
              <p className="cv-end">
                <Check /> That is the last visual in this chapter.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

const css = `
.cv { --cv-bg: var(--bg, #f6f4ef); --cv-surface: var(--surface, #fff); --cv-ink: var(--ink, #1d1f24); --cv-muted: var(--muted, #5d6270); --cv-line: var(--line, #d9d5cc); --cv-accent: var(--accent, #1f5f7a); --cv-soft: var(--accent-soft, #dcebf1); }
.cv *, .cv *::before, .cv *::after { box-sizing: border-box; }
.cv button { font: inherit; color: inherit; cursor: pointer; }
.cv button:disabled { cursor: not-allowed; opacity: .45; }
.cv button:focus-visible, .cv a:focus-visible, .cv h3:focus-visible { outline: 3px solid var(--cv-accent); outline-offset: 2px; }
.cv-sr { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; border: 0; }

.cv-bar { display: flex; flex-wrap: wrap; align-items: center; gap: 10px 14px; padding: 10px 12px; margin-bottom: 16px; border: 1px solid var(--cv-line); border-radius: 12px; background: var(--cv-bg); }
.cv-pos { margin: 0; flex: 1 1 140px; font-size: 14px; color: var(--cv-muted); }
.cv-pos strong { color: var(--cv-ink); }
.cv-steps { display: flex; gap: 8px; margin-left: auto; }
.cv-btn { display: inline-flex; align-items: center; justify-content: center; gap: 6px; min-height: 44px; padding: 8px 14px; border: 1px solid var(--cv-line); border-radius: 10px; background: var(--cv-surface); color: var(--cv-ink); font-weight: 600; text-decoration: none; }
.cv-btn:hover:not(:disabled) { border-color: var(--cv-accent); }
.cv-primary { background: var(--cv-accent); border-color: var(--cv-accent); color: var(--cv-bg); }
.cv-browse { display: inline-flex; align-items: center; gap: 8px; min-height: 44px; padding: 8px 14px; border: 1px solid var(--cv-accent); border-radius: 10px; background: var(--cv-soft); font-weight: 600; }

.cv-body { display: grid; grid-template-columns: minmax(0, 1fr); gap: 20px; align-items: start; }
.cv-list { display: none; gap: 16px; padding: 14px; border: 1px solid var(--cv-line); border-radius: 12px; background: var(--cv-bg); }
.cv-open .cv-list { display: grid; }
.cv-group { display: grid; gap: 6px; }
.cv-group-label { display: flex; justify-content: space-between; align-items: baseline; gap: 8px; margin: 0 0 2px; padding-bottom: 4px; border-bottom: 1px solid var(--cv-line); font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: .05em; color: var(--cv-muted); }
.cv-count { flex: none; white-space: nowrap; font-weight: 500; text-transform: none; letter-spacing: 0; }
.cv-items { display: grid; gap: 4px; margin: 0; padding: 0; list-style: none; }
.cv-item { position: relative; display: flex; align-items: center; gap: 10px; width: 100%; min-height: 44px; padding: 8px 10px 8px 12px; text-align: left; border: 1px solid transparent; border-left: 4px solid transparent; border-radius: 8px; background: transparent; }
.cv-item:hover { background: var(--cv-soft); }
.cv-item[aria-current="true"] { background: var(--cv-soft); border-color: var(--cv-accent); border-left-color: var(--cv-accent); font-weight: 600; }
.cv-num { flex: none; display: inline-flex; align-items: center; justify-content: center; width: 26px; height: 26px; border-radius: 50%; border: 1px solid var(--cv-line); background: var(--cv-surface); font-size: 12px; font-weight: 700; color: var(--cv-muted); }
.cv-item[aria-current="true"] .cv-num { background: var(--cv-accent); border-color: var(--cv-accent); color: var(--cv-bg); }
.cv-title { flex: 1; min-width: 0; line-height: 1.3; }
.cv-tag { flex: none; padding: 1px 8px; border-radius: 999px; background: var(--cv-accent); color: var(--cv-bg); font-size: 11px; font-weight: 700; }
.cv-done { flex: none; display: inline-flex; color: var(--cv-accent); }
.cv-foot { display: flex; justify-content: space-between; align-items: center; gap: 8px; padding-top: 10px; border-top: 1px solid var(--cv-line); font-size: 13px; color: var(--cv-muted); }
.cv-link { padding: 6px 4px; border: 0; background: none; color: var(--cv-accent); font-size: 13px; font-weight: 600; text-decoration: underline; }

.cv-main { min-width: 0; }
.cv-head { display: grid; gap: 6px; justify-items: start; margin-bottom: 14px; }
.cv-kicker { margin: 0; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: .05em; color: var(--cv-accent); }
.cv-head h3 { margin: 0; font-size: 22px; line-height: 1.2; }
.cv-text { margin: 0; max-width: 68ch; color: var(--cv-ink); }
.cv-covers { margin: 0; font-size: 14px; color: var(--cv-muted); }
.cv-covers strong { color: var(--cv-ink); }
.cv-open-link { margin-top: 6px; }
.cv-frame { display: block; width: 100%; height: min(78vh, 820px); min-height: 480px; border: 1px solid var(--cv-line); border-radius: 12px; background: var(--cv-bg); }
.cv-next { margin-top: 14px; }
.cv-upnext { display: grid; gap: 2px; width: 100%; padding: 12px 16px; text-align: left; border: 1px solid var(--cv-line); border-radius: 12px; background: var(--cv-surface); }
.cv-upnext:hover { border-color: var(--cv-accent); background: var(--cv-soft); }
.cv-upnext-label { font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: .05em; color: var(--cv-muted); }
.cv-upnext-title { font-weight: 600; color: var(--cv-accent); }
.cv-end { display: flex; align-items: center; gap: 8px; margin: 0; padding: 12px 16px; border: 1px dashed var(--cv-line); border-radius: 12px; color: var(--cv-muted); }

@media (min-width: 900px) {
  .cv-browse { display: none; }
  .cv-body { grid-template-columns: 290px minmax(0, 1fr); }
  .cv-list { display: grid; position: sticky; top: 16px; max-height: calc(100vh - 32px); overflow-y: auto; overscroll-behavior: contain; }
}
@media (max-width: 899px) {
  .cv-frame { min-height: 440px; }
  .cv-steps { margin-left: 0; width: 100%; }
  .cv-steps .cv-btn { flex: 1; }
}
@media (prefers-reduced-motion: reduce) { .cv * { transition: none !important; scroll-behavior: auto !important; } }
`;
